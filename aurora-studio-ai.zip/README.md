# AURORA STUDIO AI — working vertical slice

A single-page Next.js app: prompt workspace, style presets, gallery, detail viewer,
favorites, collections, settings, and a server generation endpoint with zod validation
and a 10 req/min per-IP in-memory rate limit.

## Stack (verified in this repo)
- Next.js 15.5.28, React 19, TypeScript strict, Tailwind CSS v4 (`@tailwindcss/postcss`), zod.
- No shadcn, no database, no auth, no object storage in this slice (see Limitations).

## Run locally
```bash
cd aurora-studio-ai
cp .env.example .env.local   # leave OPENAI_API_KEY blank for demo mode
npm install
npm run dev                  # http://localhost:3000
npm test                     # plain-JS validation mirror (see scripts/test.mjs)
npm run build
npm start
```

## Generation: demo vs real — honest distinction
- **No `OPENAI_API_KEY`:** `POST /api/generate` returns `mode: "demo"` and the
  labelled SVG samples in `public/demo/` (each SVG itself says "AURORA DEMO SAMPLE —
  Not AI-generated"). The UI also shows a "DEMO — sample image, not AI-generated" banner.
- **With `OPENAI_API_KEY` set server-side (`.env.local`, never in client code):**
  the server adapter calls `POST https://api.openai.com/v1/images/generations` with
  `IMAGE_MODEL` (default `gpt-image-1`), mapped size for the aspect ratio, and `n`
  = count. Returned URLs (or base64 data) are passed through in `mode: "real"`.
  The key is never exposed to the browser.

## API
`POST /api/generate` — JSON body:
`{ prompt: string (3–1000), aspectRatio: "1:1"|"3:2"|"2:3"|"4:3"|"3:4"|"16:9"|"9:16",
count: 1–4, quality: "standard"|"high", style: one of the 12 presets,
seed?: int, negativePrompt?: string }`
Response: `{ mode, job: { id, state }, images: [{ id, url, prompt, model, aspectRatio, style, quality, createdAt, mode }] }`
Errors: 400 validation, 429 rate limit, 502 provider failure (generic message, no secrets).

## Limitations (not yet implemented / not tested)
- No accounts, per-user server isolation, database, or cloud storage: history,
  favorites and collections persist in the browser's localStorage only.
- No public Explore feed, no image-to-image upload, no transparent-background
  control: those controls are not presented as functional.
- Real OpenAI generation is **untested without a key** — it requires a valid
  `OPENAI_API_KEY` and will incur provider charges. Do not claim a real generation
  succeeded until one has actually run with a key.
- Tests run here are the plain-JS validation mirror in `scripts/test.mjs` only.
  No vitest or Playwright suite was run (none installed), and no E2E browser
  test was performed in this build.
- Rate limiting is in-memory per server instance; it does not survive restarts
  or scale across instances.

## Deploy (Vercel)
1. Push this folder as its own repo (or Vercel project root = `aurora-studio-ai`).
2. In Vercel project settings, set `OPENAI_API_KEY` (optional — blank = demo)
   and `IMAGE_MODEL` (optional, default `gpt-image-1`) as environment variables.
3. Deploy; Next.js 15.5.28 is used deliberately (15.3.4 is blocked by Vercel
   for a known vulnerability).
4. Verify: open the app, try an example prompt, confirm demo labelling when no
   key is set, and confirm a real generation only after a key is added.
