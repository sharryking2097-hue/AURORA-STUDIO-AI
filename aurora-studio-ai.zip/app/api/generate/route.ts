import { NextRequest, NextResponse } from "next/server";
import { validateGenerate } from "@/lib/validation";
import { generateImages, providerMode } from "@/lib/providers";

const WINDOW_MS = 60_000;
const LIMIT = 10;
const hits = new Map<string, number[]>();
function rateLimited(ip: string): boolean {
  const now = Date.now();
  const list = (hits.get(ip) ?? []).filter((t) => now - t < WINDOW_MS);
  if (list.length >= LIMIT) { hits.set(ip, list); return true; }
  list.push(now); hits.set(ip, list); return false;
}
export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  if (rateLimited(ip)) return NextResponse.json({ error: "Rate limit: 10 requests per minute. Please wait and retry." }, { status: 429 });
  let body: unknown;
  try { body = await req.json(); } catch { return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 }); }
  const parsed = validateGenerate(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Validation failed", issues: parsed.error.issues.map((i) => i.message) }, { status: 400 });
  }
  const jobId = `job-${Date.now()}`;
  try {
    const { mode, images } = await generateImages(parsed.data);
    return NextResponse.json({ mode, job: { id: jobId, state: "completed" }, images });
  } catch {
    return NextResponse.json({ mode: providerMode(), job: { id: jobId, state: "failed" }, error: "Image generation failed. Please retry." }, { status: 502 });
  }
}
