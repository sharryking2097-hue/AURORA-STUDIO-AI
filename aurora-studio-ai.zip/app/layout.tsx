import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "AURORA STUDIO AI", description: "Turn text prompts into images. Demo mode uses labelled sample images when no provider key is configured." };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-theme="dark" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  );
}
