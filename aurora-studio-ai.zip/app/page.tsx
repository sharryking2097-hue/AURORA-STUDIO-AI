"use client";
import { useEffect, useMemo, useState } from "react";
import Header, { type View } from "@/components/Header";
import StylePresets from "@/components/StylePresets";
import Gallery from "@/components/Gallery";
import DetailModal from "@/components/DetailModal";
import Toast from "@/components/Toast";
import type { AspectRatio, Collection, GenerationImage, Preferences, Quality } from "@/lib/types";
import { ASPECT_RATIOS, EXAMPLE_PROMPTS } from "@/lib/presets";

const LS_KEY = "aurora-studio-v1";
interface Stored { items: GenerationImage[]; favorites: string[]; collections: Collection[]; prefs: Preferences; }

function loadStored(): Stored | null {
  try { const raw = localStorage.getItem(LS_KEY); return raw ? (JSON.parse(raw) as Stored) : null; } catch { return null; }
}

export default function Home() {
  const [view, setView] = useState<View>("create");
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [prompt, setPrompt] = useState("");
  const [aspect, setAspect] = useState<AspectRatio>("1:1");
  const [count, setCount] = useState(1);
  const [quality, setQuality] = useState<Quality>("standard");
  const [style, setStyle] = useState("cinematic");
  const [seed, setSeed] = useState("");
  const [negative, setNegative] = useState("");
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [mode, setMode] = useState<string | null>(null);
  const [items, setItems] = useState<GenerationImage[]>([]);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [collections, setCollections] = useState<Collection[]>([]);
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<"newest" | "oldest">("newest");
  const [detail, setDetail] = useState<GenerationImage | null>(null);
  const [newCollection, setNewCollection] = useState("");
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const s = loadStored();
    if (s) {
      setItems(s.items ?? []); setFavorites(new Set(s.favorites ?? [])); setCollections(s.collections ?? []);
      if (s.prefs) { setTheme(s.prefs.theme); setAspect(s.prefs.defaultAspect); setStyle(s.prefs.defaultStyle); }
    }
    setLoaded(true);
  }, []);
  useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]);
  useEffect(() => {
    if (!loaded) return;
    const data: Stored = { items, favorites: [...favorites], collections, prefs: { theme, defaultAspect: aspect, defaultStyle: style } };
    try { localStorage.setItem(LS_KEY, JSON.stringify(data)); } catch { /* storage full/blocked: keep in-memory */ }
  }, [loaded, items, favorites, collections, theme, aspect, style]);
  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(null), 4000); return () => clearTimeout(t); }, [toast]);

  const promptError = prompt.length > 0 && prompt.trim().length < 3 ? "Prompt must be at least 3 characters." : prompt.length > 1000 ? "Prompt must be at most 1000 characters." : null;
  const canGenerate = !loading && !promptError && prompt.trim().length >= 3;

  async function generate(inputPrompt?: string, inputStyle?: string, inputAspect?: AspectRatio) {
    const p = (inputPrompt ?? prompt).trim();
    if (p.length < 3 || p.length > 1000) { setError("Prompt must be 3–1000 characters."); return; }
    setLoading(true); setError(null);
    try {
      const res = await fetch("/api/generate", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: p, aspectRatio: inputAspect ?? aspect, count, quality, style: inputStyle ?? style,
          seed: seed ? Number(seed) : undefined, negativePrompt: negative || undefined,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error((data as { error?: string }).error || `Generation failed (${res.status})`);
      const imgs = (data as { images: GenerationImage[]; mode: string }).images;
      setMode((data as { mode: string }).mode);
      setItems((prev) => [...imgs, ...prev]);
      setToast((data as { mode: string }).mode === "demo" ? "DEMO — sample images added (not AI-generated)." : "Images generated.");
      setView("creations");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Generation failed. Your prompt is preserved — try again.");
    } finally { setLoading(false); }
  }

  async function download(item: GenerationImage) {
    try {
      const res = await fetch(item.url);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url; a.download = `${item.id}.${item.url.endsWith(".svg") ? "svg" : "png"}`; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    } catch { window.open(item.url, "_blank", "noopener"); }
  }
  async function copyPrompt(item: GenerationImage) {
    try { await navigator.clipboard.writeText(item.prompt); setToast("Prompt copied."); }
    catch { setToast("Copy failed — select the prompt text manually."); }
  }
  function reuse(item: GenerationImage) { setPrompt(item.prompt); setStyle(item.style); setAspect(item.aspectRatio); setView("create"); setToast("Prompt reused — edit it and generate."); }
  function toggleFav(item: GenerationImage) {
    setFavorites((prev) => { const next = new Set(prev); if (next.has(item.id)) next.delete(item.id); else next.add(item.id); return next; });
  }
  function addToCollection(colId: string, item: GenerationImage) {
    setCollections((prev) => prev.map((c) => c.id === colId && !c.imageIds.includes(item.id) ? { ...c, imageIds: [...c.imageIds, item.id] } : c));
    setToast("Added to collection.");
  }
  function filtered(base: GenerationImage[]) {
    const q = search.trim().toLowerCase();
    const list = base.filter((i) => !q || i.prompt.toLowerCase().includes(q));
    return list.sort((a, b) => sort === "newest" ? b.createdAt.localeCompare(a.createdAt) : a.createdAt.localeCompare(b.createdAt));
  }
  const viewItems = useMemo(() => {
    if (view === "favorites") return filtered(items.filter((i) => favorites.has(i.id)));
    return filtered(items);
  }, [view, items, favorites, search, sort]);

  return (
    <div>
      <Header view={view} setView={setView} theme={theme} toggleTheme={() => setTheme((t) => (t === "dark" ? "light" : "dark"))} />
      <main style={{ maxWidth: 1180, margin: "0 auto", padding: "1.5rem 1rem 3rem" }}>
        {view === "create" && (
          <section aria-label="Create image">
            <h1 style={{ fontSize: "2rem", margin: "0 0 0.3rem" }}>Turn words into images.</h1>
            <p style={{ color: "var(--muted)", marginTop: 0 }}>Describe what you imagine. Keep it specific — subject, setting, light and mood help most.</p>
            {mode === "demo" && (
              <div role="status" className="panel2" style={{ padding: "0.8rem 1rem", marginBottom: "1rem" }}>
                <strong>DEMO — sample image, not AI-generated.</strong> No provider key is configured for this deployment, so generations return the labelled SVG samples in <code>public/demo/</code>. Set <code>OPENAI_API_KEY</code> server-side to use real generation.
              </div>
            )}
            <div className="panel" style={{ padding: "1.25rem" }}>
              <label htmlFor="prompt" style={{ fontWeight: 700 }}>Prompt</label>
              <textarea id="prompt" className="field" rows={5} value={prompt} onChange={(e) => setPrompt(e.target.value)}
                placeholder="A quiet mountain lake at dawn, mist over still water…" aria-describedby="prompt-count prompt-error" style={{ marginTop: "0.5rem", resize: "vertical" }} />
              <div style={{ display: "flex", justifyContent: "space-between", gap: "1rem", flexWrap: "wrap", marginTop: "0.4rem" }}>
                <span id="prompt-count" style={{ color: "var(--muted)" }}>{prompt.length} / 1000 characters</span>
                {promptError && <span id="prompt-error" role="alert" style={{ color: "var(--danger)" }}>{promptError}</span>}
              </div>
              <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginTop: "0.8rem" }} aria-label="Example prompts">
                {EXAMPLE_PROMPTS.map((ex) => <button key={ex} type="button" className="chip" onClick={() => setPrompt(ex)}>{ex}</button>)}
              </div>
              <div style={{ marginTop: "1rem" }}>
                <button type="button" className="btn" aria-expanded={advancedOpen} onClick={() => setAdvancedOpen((o) => !o)}>
                  {advancedOpen ? "▾ Hide advanced settings" : "▸ Show advanced settings"}
                </button>
                {advancedOpen && (
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(220px,1fr))", gap: "0.9rem", marginTop: "1rem" }}>
                    <label>Aspect ratio
                      <select className="field" value={aspect} onChange={(e) => setAspect(e.target.value as AspectRatio)} style={{ marginTop: "0.3rem" }}>
                        {ASPECT_RATIOS.map((a) => <option key={a} value={a}>{a}</option>)}
                      </select>
                    </label>
                    <label>Number of images (1–4)
                      <input className="field" type="number" min={1} max={4} value={count} onChange={(e) => setCount(Math.min(4, Math.max(1, Number(e.target.value) || 1)))} style={{ marginTop: "0.3rem" }} />
                    </label>
                    <label>Quality
                      <select className="field" value={quality} onChange={(e) => setQuality(e.target.value as Quality)} style={{ marginTop: "0.3rem" }}>
                        <option value="standard">Standard</option><option value="high">High</option>
                      </select>
                    </label>
                    <label>Seed (optional)
                      <input className="field" type="number" min={0} value={seed} onChange={(e) => setSeed(e.target.value)} placeholder="e.g. 42" style={{ marginTop: "0.3rem" }} />
                    </label>
                    <label>Negative prompt (optional)
                      <input className="field" value={negative} onChange={(e) => setNegative(e.target.value)} placeholder="What to avoid" style={{ marginTop: "0.3rem" }} />
                    </label>
                    <label>Model
                      <input className="field" value="Server-side IMAGE_MODEL (demo: not active)" disabled style={{ marginTop: "0.3rem", opacity: 0.7 }} />
                      <span style={{ color: "var(--muted)", fontSize: "0.85rem" }}>Model is only active when a provider key is configured server-side; it is never sent from the browser.</span>
                    </label>
                  </div>
                )}
              </div>
              <div style={{ marginTop: "1.2rem" }}><StylePresets value={style} onChange={setStyle} /></div>
              <div style={{ display: "flex", gap: "0.6rem", alignItems: "center", flexWrap: "wrap", marginTop: "1.2rem" }}>
                <button type="button" className="btn btn-primary" disabled={!canGenerate} onClick={() => generate()} style={{ padding: "0.8rem 1.6rem", fontSize: "1.05rem" }}>
                  {loading ? "Generating…" : "Generate image"}
                </button>
                {loading && <span role="status">Working — no percentage is shown because provider progress is not reported.</span>}
              </div>
              {error && (
                <div role="alert" className="panel2" style={{ padding: "0.8rem 1rem", marginTop: "1rem", borderColor: "var(--danger)" }}>
                  {error} <button type="button" className="btn" style={{ marginLeft: "0.5rem" }} onClick={() => generate()}>Retry</button>
                </div>
              )}
            </div>
            <h2 style={{ marginTop: "2rem" }}>Results</h2>
            {loading && (
              <div aria-label="Loading results" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(240px,1fr))", gap: "1rem", marginBottom: "1rem" }}>
                {[0, 1, 2].map((i) => <div key={i} className="skeleton" style={{ height: 240 }} />)}
              </div>
            )}
            <Gallery items={filtered(items)} favorites={favorites} collections={collections}
              onView={setDetail} onDownload={download} onCopy={copyPrompt} onReuse={reuse}
              onRegenerate={(i) => generate(i.prompt, i.style, i.aspectRatio)} onToggleFav={toggleFav}
              onDelete={(i) => setItems((prev) => prev.filter((x) => x.id !== i.id))} onAddToCollection={addToCollection} />
          </section>
        )}

        {view !== "create" && view !== "settings" && view !== "collections" && (
          <section aria-label={view}>
            <h1 style={{ textTransform: "capitalize" }}>{view === "creations" ? "My Creations" : view}</h1>
            <p style={{ color: "var(--muted)" }}>
              {view === "explore" ? "Explore shows your creations in this slice — no public feed is configured, so no other users' images are shown." : "Search, sort and manage your saved images. Everything here is stored in your browser (localStorage) in this slice."}
            </p>
            <div style={{ display: "flex", gap: "0.6rem", flexWrap: "wrap", marginBottom: "1rem" }}>
              <input className="field" style={{ maxWidth: 360 }} value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search prompts…" aria-label="Search prompts" />
              <select className="field" style={{ width: "auto" }} value={sort} onChange={(e) => setSort(e.target.value as "newest" | "oldest")} aria-label="Sort by date">
                <option value="newest">Newest first</option><option value="oldest">Oldest first</option>
              </select>
            </div>
            <Gallery items={viewItems} favorites={favorites} collections={collections}
              onView={setDetail} onDownload={download} onCopy={copyPrompt} onReuse={reuse}
              onRegenerate={(i) => generate(i.prompt, i.style, i.aspectRatio)} onToggleFav={toggleFav}
              onDelete={(i) => setItems((prev) => prev.filter((x) => x.id !== i.id))} onAddToCollection={addToCollection} />
          </section>
        )}

        {view === "collections" && (
          <section aria-label="Collections">
            <h1>Collections</h1>
            <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginBottom: "1rem" }}>
              <input className="field" style={{ maxWidth: 300 }} value={newCollection} onChange={(e) => setNewCollection(e.target.value)} placeholder="New collection name" aria-label="New collection name" />
              <button type="button" className="btn btn-primary" disabled={!newCollection.trim()} onClick={() => { setCollections((p) => [...p, { id: `col-${Date.now()}`, name: newCollection.trim(), imageIds: [] }]); setNewCollection(""); }}>Create collection</button>
            </div>
            {collections.length === 0 && <p style={{ color: "var(--muted)" }}>No collections yet. Create one, then use “Add to collection” on any image card.</p>}
            {collections.map((c) => (
              <div key={c.id} style={{ marginBottom: "2rem" }}>
                <h2>{c.name} ({c.imageIds.length})</h2>
                <Gallery items={items.filter((i) => c.imageIds.includes(i.id))} favorites={favorites} collections={collections}
                  onView={setDetail} onDownload={download} onCopy={copyPrompt} onReuse={reuse}
                  onRegenerate={(i) => generate(i.prompt, i.style, i.aspectRatio)} onToggleFav={toggleFav}
                  onDelete={(i) => setItems((prev) => prev.filter((x) => x.id !== i.id))} onAddToCollection={addToCollection} />
              </div>
            ))}
          </section>
        )}

        {view === "settings" && (
          <section aria-label="Settings">
            <h1>Settings</h1>
            <div className="panel" style={{ padding: "1.25rem", display: "grid", gap: "1rem", maxWidth: 640 }}>
              <label>Theme
                <select className="field" value={theme} onChange={(e) => setTheme(e.target.value as "dark" | "light")} style={{ marginTop: "0.3rem" }}>
                  <option value="dark">Dark (midnight)</option><option value="light">Light</option>
                </select>
              </label>
              <label>Default aspect ratio
                <select className="field" value={aspect} onChange={(e) => setAspect(e.target.value as AspectRatio)} style={{ marginTop: "0.3rem" }}>
                  {ASPECT_RATIOS.map((a) => <option key={a} value={a}>{a}</option>)}
                </select>
              </label>
              <label>Default style
                <select className="field" value={style} onChange={(e) => setStyle(e.target.value)} style={{ marginTop: "0.3rem" }}>
                  {["photorealistic", "cinematic", "fantasy", "anime", "digital-painting", "3d-render", "minimalist", "architecture", "product-photography", "editorial-fashion", "surrealism", "concept-art"].map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </label>
              <p style={{ color: "var(--muted)", margin: 0 }}>History, favorites and collections are stored in this browser only in this slice. No account, database or object storage is configured yet — see README limitations.</p>
              <button type="button" className="btn" style={{ borderColor: "var(--danger)", justifySelf: "start" }} onClick={() => { if (window.confirm("Clear all history, favorites and collections?")) { setItems([]); setFavorites(new Set()); setCollections([]); setToast("History cleared."); } }}>Clear all history</button>
            </div>
          </section>
        )}
      </main>
      {detail && (
        <DetailModal item={detail} items={viewItems.length ? viewItems : items} onClose={() => setDetail(null)} onSelect={setDetail}
          onDownload={download} onToggleFav={toggleFav} isFav={favorites.has(detail.id)} />
      )}
      <Toast message={toast} />
    </div>
  );
}
