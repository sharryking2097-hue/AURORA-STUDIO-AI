"use client";
import { useEffect, useRef } from "react";
import type { GenerationImage } from "@/lib/types";
export default function DetailModal({ item, items, onClose, onSelect, onDownload, onToggleFav, isFav }: {
  item: GenerationImage; items: GenerationImage[]; onClose: () => void; onSelect: (i: GenerationImage) => void;
  onDownload: (i: GenerationImage) => void; onToggleFav: (i: GenerationImage) => void; isFav: boolean;
}) {
  const closeRef = useRef<HTMLButtonElement>(null);
  const idx = items.findIndex((x) => x.id === item.id);
  useEffect(() => { closeRef.current?.focus(); }, []);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight" && idx < items.length - 1) onSelect(items[idx + 1]);
      if (e.key === "ArrowLeft" && idx > 0) onSelect(items[idx - 1]);
    };
    window.addEventListener("keydown", h); return () => window.removeEventListener("keydown", h);
  }, [idx, items, onClose, onSelect]);
  return (
    <div role="dialog" aria-modal="true" aria-label="Image details" onClick={onClose}
      style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", zIndex: 50, display: "grid", placeItems: "center", padding: "1rem" }}>
      <div className="panel" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 900, width: "100%", padding: "1rem", maxHeight: "92vh", overflow: "auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: "1rem" }}>
          <h2 style={{ margin: 0 }}>Image details</h2>
          <button ref={closeRef} type="button" className="btn" onClick={onClose} aria-label="Close details">✕ Close</button>
        </div>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={item.url} alt={item.prompt} style={{ width: "100%", height: "auto", borderRadius: 12, marginTop: "1rem", background: "var(--panel2)" }} />
        <dl style={{ display: "grid", gridTemplateColumns: "140px 1fr", gap: "0.4rem 1rem", marginTop: "1rem" }}>
          <dt>Prompt</dt><dd style={{ margin: 0 }}>{item.prompt}</dd>
          <dt>Mode</dt><dd style={{ margin: 0 }}>{item.mode === "demo" ? "DEMO — sample image, not AI-generated" : "Real provider"}</dd>
          <dt>Model</dt><dd style={{ margin: 0 }}>{item.model}</dd>
          <dt>Aspect / Style</dt><dd style={{ margin: 0 }}>{item.aspectRatio} / {item.style}</dd>
          <dt>Created</dt><dd style={{ margin: 0 }}>{new Date(item.createdAt).toLocaleString()}</dd>
        </dl>
        <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginTop: "1rem" }}>
          <button type="button" className="btn btn-primary" onClick={() => onDownload(item)}>Download</button>
          <button type="button" className="btn" onClick={() => onToggleFav(item)}>{isFav ? "★ Remove favorite" : "☆ Favorite"}</button>
          <button type="button" className="btn" disabled={idx <= 0} onClick={() => onSelect(items[idx - 1])}>← Previous</button>
          <button type="button" className="btn" disabled={idx >= items.length - 1} onClick={() => onSelect(items[idx + 1])}>Next →</button>
        </div>
      </div>
    </div>
  );
}
