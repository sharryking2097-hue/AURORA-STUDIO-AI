"use client";
import { useState } from "react";
import type { GenerationImage } from "@/lib/types";
function ratioStyle(r: string): string {
  const [w, h] = r.split(":").map(Number); return `${w} / ${h}`;
}
export default function Gallery({ items, favorites, collections, onView, onDownload, onCopy, onReuse, onRegenerate, onToggleFav, onDelete, onAddToCollection }: {
  items: GenerationImage[]; favorites: Set<string>; collections: { id: string; name: string }[];
  onView: (i: GenerationImage) => void; onDownload: (i: GenerationImage) => void; onCopy: (i: GenerationImage) => void;
  onReuse: (i: GenerationImage) => void; onRegenerate: (i: GenerationImage) => void; onToggleFav: (i: GenerationImage) => void;
  onDelete: (i: GenerationImage) => void; onAddToCollection: (colId: string, i: GenerationImage) => void;
}) {
  const [confirmId, setConfirmId] = useState<string | null>(null);
  if (!items.length) {
    return (
      <div className="panel" style={{ padding: "2rem", textAlign: "center" }}>
        <h3 style={{ marginTop: 0 }}>Nothing here yet</h3>
        <p style={{ color: "var(--muted)" }}>Generate an image above, or try an example prompt. In demo mode you will see clearly labelled sample images.</p>
      </div>
    );
  }
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(240px,1fr))", gap: "1rem" }}>
      {items.map((item) => (
        <article key={item.id} className="panel" style={{ overflow: "hidden" }}>
          <button type="button" onClick={() => onView(item)} aria-label={`View ${item.prompt}`} style={{ display: "block", width: "100%", border: "none", background: "transparent", padding: 0, cursor: "pointer" }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={item.url} alt={item.prompt} loading="lazy" style={{ width: "100%", aspectRatio: ratioStyle(item.aspectRatio), objectFit: "cover", display: "block", background: "var(--panel2)" }} />
          </button>
          <div style={{ padding: "0.8rem" }}>
            <p style={{ margin: "0 0 0.4rem", fontSize: "0.92rem" }}>{item.prompt}</p>
            <p style={{ margin: 0, color: "var(--muted)", fontSize: "0.82rem" }}>{item.mode === "demo" ? "DEMO — sample image, not AI-generated" : `Real · ${item.model}`} · {item.aspectRatio} · {item.style}</p>
            <div style={{ display: "flex", gap: "0.4rem", flexWrap: "wrap", marginTop: "0.7rem" }}>
              <button type="button" className="btn" onClick={() => onDownload(item)}>Download</button>
              <button type="button" className="btn" onClick={() => onCopy(item)}>Copy prompt</button>
              <button type="button" className="btn" onClick={() => onReuse(item)}>Reuse</button>
              <button type="button" className="btn" onClick={() => onRegenerate(item)}>Regenerate</button>
              <button type="button" className="btn" aria-pressed={favorites.has(item.id)} onClick={() => onToggleFav(item)}>{favorites.has(item.id) ? "★ Fav" : "☆ Fav"}</button>
              {collections.length > 0 && (
                <select className="field" aria-label={`Add to collection for ${item.prompt}`} defaultValue="" onChange={(e) => { if (e.target.value) { onAddToCollection(e.target.value, item); e.target.value = ""; } }} style={{ width: "auto" }}>
                  <option value="" disabled>Add to collection…</option>
                  {collections.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              )}
              {confirmId === item.id ? (
                <>
                  <button type="button" className="btn" style={{ borderColor: "var(--danger)" }} onClick={() => { onDelete(item); setConfirmId(null); }}>Confirm delete</button>
                  <button type="button" className="btn" onClick={() => setConfirmId(null)}>Cancel</button>
                </>
              ) : (
                <button type="button" className="btn" onClick={() => setConfirmId(item.id)}>Delete</button>
              )}
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}
