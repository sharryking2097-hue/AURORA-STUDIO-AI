"use client";
export type View = "create" | "explore" | "creations" | "favorites" | "collections" | "settings";
const NAV: { id: View; label: string }[] = [
  { id: "create", label: "Create" },
  { id: "explore", label: "Explore" },
  { id: "creations", label: "My Creations" },
  { id: "favorites", label: "Favorites" },
  { id: "collections", label: "Collections" },
  { id: "settings", label: "Settings" },
];
export default function Header({ view, setView, theme, toggleTheme }: { view: View; setView: (v: View) => void; theme: string; toggleTheme: () => void }) {
  return (
    <header style={{ borderBottom: "1px solid var(--border)", position: "sticky", top: 0, background: "var(--bg)", zIndex: 20 }}>
      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "0.9rem 1rem", display: "flex", gap: "1rem", alignItems: "center", flexWrap: "wrap" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.6rem" }}>
          <span aria-hidden="true" style={{ width: 34, height: 34, borderRadius: 10, background: "linear-gradient(135deg,#8b5cf6,#38bdf8)", display: "grid", placeItems: "center", fontWeight: 800, color: "#fff" }}>A</span>
          <strong>AURORA STUDIO AI</strong>
        </div>
        <nav aria-label="Main" style={{ display: "flex", gap: "0.25rem", flexWrap: "wrap", marginLeft: "auto" }}>
          {NAV.map((n) => (
            <button key={n.id} type="button" className="btn" aria-current={view === n.id ? "page" : undefined}
              style={view === n.id ? { borderColor: "var(--accent)", fontWeight: 700 } : { borderColor: "transparent", background: "transparent" }}
              onClick={() => setView(n.id)}>{n.label}</button>
          ))}
          <button type="button" className="btn" onClick={toggleTheme} aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} theme`}>
            {theme === "dark" ? "☀️ Light" : "🌙 Dark"}
          </button>
        </nav>
      </div>
    </header>
  );
}
