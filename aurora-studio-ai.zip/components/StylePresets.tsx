"use client";
import { STYLE_PRESETS } from "@/lib/presets";
export default function StylePresets({ value, onChange }: { value: string; onChange: (id: string) => void }) {
  return (
    <fieldset>
      <legend style={{ fontWeight: 700, marginBottom: "0.5rem" }}>Style presets</legend>
      <p style={{ color: "var(--muted)", marginTop: 0 }}>Choosing a preset updates style only — it never wipes your prompt.</p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(210px,1fr))", gap: "0.6rem" }}>
        {STYLE_PRESETS.map((p) => (
          <button key={p.id} type="button" className="chip" aria-pressed={value === p.id} onClick={() => onChange(p.id)}>
            <strong style={{ display: "block" }}>{p.name}</strong>
            <span style={{ color: "var(--muted)", fontSize: "0.9rem" }}>{p.description}</span>
          </button>
        ))}
      </div>
    </fieldset>
  );
}
