"use client";
export default function Toast({ message }: { message: string | null }) {
  if (!message) return null;
  return <div role="status" aria-live="polite" style={{ position: "fixed", bottom: "1rem", right: "1rem", zIndex: 60, background: "var(--panel)", border: "1px solid var(--accent)", borderRadius: 12, padding: "0.8rem 1rem", maxWidth: "min(92vw,420px)" }}>{message}</div>;
}
