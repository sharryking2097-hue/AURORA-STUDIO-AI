export interface StylePreset { id: string; name: string; description: string; }
export const STYLE_PRESETS: StylePreset[] = [
  { id: "photorealistic", name: "Photorealistic", description: "Lifelike detail, natural light and texture." },
  { id: "cinematic", name: "Cinematic", description: "Film-like framing, mood and colour grade." },
  { id: "fantasy", name: "Fantasy", description: "Otherworldly scenes, magic and wonder." },
  { id: "anime", name: "Anime", description: "Clean cel style, expressive characters." },
  { id: "digital-painting", name: "Digital painting", description: "Painterly brushwork and rich colour." },
  { id: "3d-render", name: "3D render", description: "Polished CG look, soft studio lighting." },
  { id: "minimalist", name: "Minimalist", description: "Simple forms, generous negative space." },
  { id: "architecture", name: "Architecture", description: "Clean lines, structure and perspective." },
  { id: "product-photography", name: "Product photography", description: "Studio product shots, crisp and clean." },
  { id: "editorial-fashion", name: "Editorial fashion", description: "High-fashion styling and composition." },
  { id: "surrealism", name: "Surrealism", description: "Dream logic, unexpected juxtapositions." },
  { id: "concept-art", name: "Concept art", description: "Imaginative world-building sketches." },
];
export const ASPECT_RATIOS = ["1:1", "3:2", "2:3", "4:3", "3:4", "16:9", "9:16"] as const;
export const EXAMPLE_PROMPTS = [
  "A quiet mountain lake at dawn, mist over still water, cinematic light",
  "A cosy reading nook by a large window, warm lamps, rain outside",
  "A futuristic market street at night, neon signs, gentle rain",
  "A single lighthouse on a rocky coast under a violet evening sky",
];
