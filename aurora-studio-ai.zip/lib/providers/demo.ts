import type { GenerateInput } from "../validation";
import type { GenerationImage, Mode } from "../types";
const SAMPLES = ["/demo/demo-1.svg", "/demo/demo-2.svg", "/demo/demo-3.svg", "/demo/demo-4.svg"];
export function demoImages(input: GenerateInput): GenerationImage[] {
  const now = new Date().toISOString();
  return Array.from({ length: input.count }, (_, i) => ({
    id: `demo-${Date.now()}-${i}`,
    url: SAMPLES[i % SAMPLES.length],
    prompt: input.prompt,
    model: "demo",
    aspectRatio: input.aspectRatio,
    style: input.style,
    quality: input.quality,
    createdAt: now,
    mode: "demo" as Mode,
  }));
}
