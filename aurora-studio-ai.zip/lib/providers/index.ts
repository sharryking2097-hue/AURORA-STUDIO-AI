import type { GenerateInput } from "../validation";
import type { GenerationImage, Mode } from "../types";
import { demoImages } from "./demo";
import { openaiImages } from "./openai";
export function providerMode(): Mode { return process.env.OPENAI_API_KEY ? "real" : "demo"; }
export async function generateImages(input: GenerateInput): Promise<{ mode: Mode; images: GenerationImage[] }> {
  const key = process.env.OPENAI_API_KEY;
  if (!key) return { mode: "demo", images: demoImages(input) };
  const model = process.env.IMAGE_MODEL || "gpt-image-1";
  return { mode: "real", images: await openaiImages(input, key, model) };
}
