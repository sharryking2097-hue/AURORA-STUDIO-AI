import type { GenerateInput } from "../validation";
import type { AspectRatio, GenerationImage } from "../types";
function sizeFor(aspect: AspectRatio): string {
  if (aspect === "1:1") return "1024x1024";
  if (["3:2", "4:3", "16:9"].includes(aspect)) return "1536x1024";
  return "1024x1536";
}
export async function openaiImages(input: GenerateInput, apiKey: string, model: string): Promise<GenerationImage[]> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 120000);
  try {
    const enhanced = `${input.prompt} [style: ${input.style}]${input.negativePrompt ? ` Avoid: ${input.negativePrompt}` : ""}`;
    const res = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      signal: controller.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({ model, prompt: enhanced, n: input.count, size: sizeFor(input.aspectRatio) }),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      // Do not leak provider internals beyond status; keep message generic.
      throw new Error(`Provider request failed with status ${res.status}${text ? "" : ""}`);
    }
    const data = await res.json() as { data?: Array<{ url?: string; b64_json?: string }> };
    const now = new Date().toISOString();
    const items = (data.data ?? []).map((d, i) => ({
      id: `openai-${Date.now()}-${i}`,
      url: d.url ?? (d.b64_json ? `data:image/png;base64,${d.b64_json}` : ""),
      prompt: input.prompt, model, aspectRatio: input.aspectRatio, style: input.style,
      quality: input.quality, createdAt: now, mode: "real" as const,
    })).filter((x) => x.url);
    if (!items.length) throw new Error("Provider returned no images");
    return items;
  } finally { clearTimeout(timer); }
}
