export type AspectRatio = "1:1" | "3:2" | "2:3" | "4:3" | "3:4" | "16:9" | "9:16";
export type Quality = "standard" | "high";
export type JobState = "queued" | "processing" | "completed" | "failed" | "canceled";
export type Mode = "demo" | "real";
export interface GenerationImage {
  id: string;
  url: string;
  prompt: string;
  model: string;
  aspectRatio: AspectRatio;
  style: string;
  quality: Quality;
  createdAt: string;
  mode: Mode;
}
export interface GenerateResponse {
  mode: Mode;
  job: { id: string; state: JobState };
  images: GenerationImage[];
}
export interface Collection { id: string; name: string; imageIds: string[]; }
export interface Preferences { theme: "dark" | "light"; defaultAspect: AspectRatio; defaultStyle: string; }
