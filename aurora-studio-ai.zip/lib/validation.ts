import { z } from "zod";
import { ASPECT_RATIOS, STYLE_PRESETS } from "./presets";
export const generateSchema = z.object({
  prompt: z.string().trim().min(3, "Prompt must be at least 3 characters").max(1000, "Prompt must be at most 1000 characters"),
  aspectRatio: z.enum(ASPECT_RATIOS),
  count: z.number().int().min(1).max(4),
  quality: z.enum(["standard", "high"]).default("standard"),
  style: z.enum(STYLE_PRESETS.map((p) => p.id) as [string, ...string[]]),
  seed: z.number().int().min(0).max(999999999).optional(),
  negativePrompt: z.string().max(500).optional(),
  model: z.string().max(100).optional(),
});
export type GenerateInput = z.infer<typeof generateSchema>;
export function validateGenerate(body: unknown) { return generateSchema.safeParse(body); }
