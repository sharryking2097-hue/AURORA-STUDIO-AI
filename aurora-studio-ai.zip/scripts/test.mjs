// Honest scope: this script does NOT run vitest/playwright and does NOT import
// the TypeScript zod schema (no TS runner is installed). It duplicates the
// validation rules from lib/validation.ts in plain JS so the same boundaries
// are checked without extra dependencies. If lib/validation.ts changes, update
// this file to match and note the change in README.
const ASPECTS = ["1:1","3:2","2:3","4:3","3:4","16:9","9:16"];
const STYLES = ["photorealistic","cinematic","fantasy","anime","digital-painting","3d-render","minimalist","architecture","product-photography","editorial-fashion","surrealism","concept-art"];
function validate(input) {
  const errors = [];
  if (typeof input.prompt !== "string" || input.prompt.trim().length < 3) errors.push("prompt too short");
  if (typeof input.prompt === "string" && input.prompt.length > 1000) errors.push("prompt too long");
  if (!ASPECTS.includes(input.aspectRatio)) errors.push("bad aspect");
  if (!Number.isInteger(input.count) || input.count < 1 || input.count > 4) errors.push("bad count");
  if (!STYLES.includes(input.style)) errors.push("bad style");
  if (input.seed !== undefined && (!Number.isInteger(input.seed) || input.seed < 0)) errors.push("bad seed");
  return errors;
}
const cases = [
  ["empty prompt rejected", { prompt: "", aspectRatio: "1:1", count: 1, style: "cinematic" }, true],
  ["short prompt rejected", { prompt: "ab", aspectRatio: "1:1", count: 1, style: "cinematic" }, true],
  ["long prompt rejected", { prompt: "x".repeat(1001), aspectRatio: "1:1", count: 1, style: "cinematic" }, true],
  ["bad aspect rejected", { prompt: "a nice lake", aspectRatio: "5:5", count: 1, style: "cinematic" }, true],
  ["bad count rejected", { prompt: "a nice lake", aspectRatio: "1:1", count: 9, style: "cinematic" }, true],
  ["bad style rejected", { prompt: "a nice lake", aspectRatio: "1:1", count: 1, style: "nope" }, true],
  ["valid passes", { prompt: "a quiet mountain lake at dawn", aspectRatio: "16:9", count: 2, style: "cinematic" }, false],
  ["valid with seed passes", { prompt: "a quiet mountain lake at dawn", aspectRatio: "1:1", count: 1, style: "fantasy", seed: 42 }, false],
];
let failed = 0;
for (const [name, input, expectError] of cases) {
  const errs = validate(input);
  const ok = expectError ? errs.length > 0 : errs.length === 0;
  console.log(`${ok ? "PASS" : "FAIL"} ${name}${ok ? "" : ` (errors: ${errs.join(", ")})`}`);
  if (!ok) failed++;
}
if (failed) { console.error(`${failed} case(s) failed`); process.exit(1); }
console.log("All validation cases passed (plain-JS mirror of lib/validation.ts; zod schema itself is exercised by the API route at runtime).");
